import 'dart:async';
import 'package:dio/dio.dart';

class API {

    Future<dynamic> signIn(String email, String password) async {

      FormData formData = new FormData.fromMap({
        "email": email,
        "password": password
      });

      try {
        var response = await Dio().post(
          "https://localhost:44357/api/login/signIn",
          data: formData);
        
        return response;
      } catch (e) {
        print(e);
      }
    }
}