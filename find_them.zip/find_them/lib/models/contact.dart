import 'package:meta/meta.dart';

class Contact {
  final String avatarUrl;
  final String name;

  Contact({@required this.avatarUrl, @required this.name});
}